const config = {
    // Change this to your deployed backend URL after deployment
    apiUrl: window.location.hostname === 'localhost' 
        ? 'http://localhost:3000' 
        : 'https://your-render-url.onrender.com'
};
